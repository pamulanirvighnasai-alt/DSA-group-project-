const form = document.getElementById("symptom-form");
const symptomsField = document.getElementById("symptoms");
const charCount = document.getElementById("char-count");
const errorBox = document.getElementById("form-error");
const emptyState = document.getElementById("empty-state");
const resultsContent = document.getElementById("results-content");

symptomsField.addEventListener("input", () => {
  charCount.textContent = `${symptomsField.value.length} / 1200`;
});

document.querySelectorAll("[data-example]").forEach(button => {
  button.addEventListener("click", () => {
    symptomsField.value = button.dataset.example;
    charCount.textContent = `${symptomsField.value.length} / 1200`;
    symptomsField.focus();
  });
});

form.addEventListener("submit", async event => {
  event.preventDefault();
  errorBox.textContent = "";
  const symptoms = symptomsField.value.trim();
  if (!symptoms) {
    errorBox.textContent = "Please enter a symptom description first.";
    return;
  }

  const submitButton = form.querySelector("button[type='submit']");
  submitButton.disabled = true;
  submitButton.querySelector("span:first-child").textContent = "Matching...";
  try {
    const response = await fetch("/api/match", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ symptoms })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not process the request.");
    renderResults(data);
  } catch (error) {
    errorBox.textContent = "Could not reach the Java backend. Make sure the terminal server is still running.";
  } finally {
    submitButton.disabled = false;
    submitButton.querySelector("span:first-child").textContent = "Match symptoms";
  }
});

function renderResults(data) {
  emptyState.hidden = true;
  resultsContent.hidden = false;
  const recognized = document.getElementById("recognized");
  recognized.replaceChildren();
  data.recognized.forEach(symptom => {
    const tag = document.createElement("span");
    tag.className = "tag";
    tag.textContent = symptom;
    recognized.appendChild(tag);
  });

  const list = document.getElementById("result-list");
  list.replaceChildren();
  if (!data.results.length) {
    const message = document.createElement("p");
    message.className = "muted";
    message.textContent = data.message || "No sample condition matched these symptoms. Try a different description.";
    list.appendChild(message);
  } else {
    data.results.forEach((result, index) => {
      const card = document.createElement("article");
      card.className = "result-card";
      const top = document.createElement("div");
      top.className = "result-top";
      const details = document.createElement("div");
      const title = document.createElement("h3");
      title.textContent = `${index + 1}. ${result.name}`;
      const description = document.createElement("p");
      description.textContent = result.description;
      details.append(title, description);
      const score = document.createElement("span");
      score.className = "score";
      score.textContent = `${result.score}% match`;
      top.append(details, score);
      const bar = document.createElement("div");
      bar.className = "bar";
      const fill = document.createElement("span");
      fill.style.width = `${Math.max(4, Math.min(100, result.score))}%`;
      bar.appendChild(fill);
      const matched = document.createElement("div");
      matched.className = "matched";
      const label = document.createElement("b");
      label.textContent = "Matching symptoms: ";
      matched.appendChild(label);
      matched.appendChild(document.createTextNode(result.matched.join(", ")));
      card.append(top, bar, matched);
      list.appendChild(card);
    });
  }

  const testList = document.getElementById("test-list");
  testList.replaceChildren();
  if (!data.tests.length) {
    const li = document.createElement("li");
    li.textContent = "No example assessments were identified for these recognized symptoms.";
    testList.appendChild(li);
  } else {
    data.tests.forEach(test => {
      const li = document.createElement("li");
      li.textContent = test;
      testList.appendChild(li);
    });
  }
  document.getElementById("score-note").textContent = data.message || "";
  document.getElementById("results-panel").scrollIntoView({ behavior: "smooth", block: "start" });
}
