# Symptom-to-Diagnosis Matcher (Java DSA Project)

A classroom demonstration of a symptom-matching decision-support website. It includes:
- Frontend: HTML, CSS, JavaScript
- Backend: Java built-in `HttpServer` (no external libraries)
- DSA concepts: HashMap, HashSet, ArrayList, weighted scoring, sorting, greedy test selection
- Lightweight text normalization: lowercase, punctuation cleanup, synonym mapping, common typo mapping
- Ranked educational matches and suggested differentiating tests

## Important medical limitation
This is an educational prototype, not a medical device. Its small, hand-written knowledge base is not clinically validated and must not be used to diagnose, treat, or rule out disease. It does not provide real medical confidence/probability. For severe symptoms, seek urgent medical care; users should consult a qualified healthcare professional.

## Requirements
- JDK 11 or newer
- No Maven, Gradle, database, or internet connection required

## Run on Windows
1. Extract the ZIP.
2. Open the extracted folder.
3. Open Command Prompt in this folder (File Explorer address bar -> type `cmd` -> Enter).
4. Compile:
   `javac --add-modules jdk.httpserver SymptomMatcherServer.java`
5. Run:
   `java --add-modules jdk.httpserver SymptomMatcherServer`
6. Open `http://localhost:8081` in your browser.
7. Keep the terminal open while using the site. Press `Ctrl+C` to stop the server.

If `javac` is not recognized, install a JDK (not only a JRE), then reopen Command Prompt.

## Try these example inputs
- `fever, cough, sore throat`
- `runny nose, sneezing, itchy eyes`
- `headache, nausea, sensitivity to light`

## How the algorithm works
1. Normalize the entered text and map common terms to canonical symptoms.
2. Convert the normalized symptoms into a `HashSet` to remove duplicates.
3. For every condition, calculate a weighted score from matching symptoms.
4. Sort the results from highest to lowest score.
5. Recommend a small set of example tests that separate the top candidates using a greedy coverage strategy.

The score shown is a *matching score*, not a medical probability. The knowledge base and weights are illustrative only.

## Project structure
- `SymptomMatcherServer.java` — HTTP server, API endpoint, sample knowledge base, NLP normalization, scoring and test-selection algorithm
- `public/index.html` — page structure
- `public/styles.css` — visual design
- `public/app.js` — form handling and API request

## Suggested viva explanation
"The browser displays a form and sends the symptom text to our Java backend using HTTP. The backend normalizes words using a HashMap of synonyms and common spelling variants, stores recognized symptoms in a HashSet to avoid duplicates, scores each condition using weighted symptom matches, sorts the results, and uses a greedy set-cover-style method to suggest tests that may help distinguish the leading candidates. The result is an educational matching aid, not a clinical diagnosis."
