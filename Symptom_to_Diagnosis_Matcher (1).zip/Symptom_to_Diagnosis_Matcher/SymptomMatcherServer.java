import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Educational prototype only. Not for medical diagnosis or treatment.
 * Requires JDK 11+; uses the built-in jdk.httpserver module.
 */
public class SymptomMatcherServer {
    private static final int PORT = 8081;
    private static final Path PUBLIC_DIR = Path.of("public");

    static class Condition {
        String name;
        String description;
        Map<String, Integer> symptomWeights;
        Map<String, String> testBySymptom;

        Condition(String name, String description, Map<String, Integer> weights,
                  Map<String, String> tests) {
            this.name = name;
            this.description = description;
            this.symptomWeights = weights;
            this.testBySymptom = tests;
        }
    }

    private static final Map<String, String> NORMALIZATION = new HashMap<>();
    private static final List<Condition> KNOWLEDGE_BASE = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        seedNormalization();
        seedKnowledgeBase();

        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.createContext("/api/match", SymptomMatcherServer::handleMatch);
        server.createContext("/", SymptomMatcherServer::handleStatic);
        server.setExecutor(null);
        server.start();
        System.out.println("Symptom-to-Diagnosis Matcher running at http://localhost:" + PORT);
        System.out.println("Educational demo only. Press Ctrl+C to stop.");
    }

    private static void seedNormalization() {
        // Map common phrases, synonyms and a few frequent misspellings to canonical terms.
        String[][] aliases = {
            {"high temperature", "fever"}, {"temperature", "fever"}, {"fever", "fever"}, {"feaver", "fever"},
            {"coughing", "cough"}, {"cough", "cough"}, {"throat pain", "sore throat"},
            {"throat ache", "sore throat"}, {"sore throat", "sore throat"},
            {"blocked nose", "runny nose"}, {"stuffy nose", "runny nose"}, {"runny nose", "runny nose"},
            {"sneezing", "sneezing"}, {"sneeze", "sneezing"}, {"itchy eyes", "itchy eyes"},
            {"watery eyes", "itchy eyes"}, {"body ache", "body aches"}, {"body aches", "body aches"},
            {"muscle pain", "body aches"}, {"tiredness", "fatigue"}, {"fatigue", "fatigue"},
            {"shortness of breath", "shortness of breath"}, {"breathlessness", "shortness of breath"},
            {"headache", "headache"}, {"head ache", "headache"}, {"nausea", "nausea"},
            {"feeling sick", "nausea"}, {"vomiting", "vomiting"}, {"throwing up", "vomiting"},
            {"sensitivity to light", "light sensitivity"}, {"light sensitivity", "light sensitivity"},
            {"diarrhea", "diarrhea"}, {"loose motions", "diarrhea"}, {"loose motion", "diarrhea"},
            {"stomach pain", "abdominal pain"}, {"abdominal pain", "abdominal pain"},
            {"belly pain", "abdominal pain"}, {"rash", "rash"}, {"itchy skin", "rash"},
            {"chest pain", "chest pain"}, {"dizziness", "dizziness"}, {"dizzy", "dizziness"},
            {"loss of smell", "loss of smell"}, {"loss of taste", "loss of taste"}
        };
        for (String[] pair : aliases) NORMALIZATION.put(pair[0], pair[1]);
    }

    private static Map<String, Integer> weights(String... pairs) {
        Map<String, Integer> map = new LinkedHashMap<>();
        for (int i = 0; i + 1 < pairs.length; i += 2)
            map.put(pairs[i], Integer.parseInt(pairs[i + 1]));
        return map;
    }

    private static Map<String, String> tests(String... pairs) {
        Map<String, String> map = new LinkedHashMap<>();
        for (int i = 0; i + 1 < pairs.length; i += 2) map.put(pairs[i], pairs[i + 1]);
        return map;
    }

    private static void seedKnowledgeBase() {
        KNOWLEDGE_BASE.add(new Condition("Common cold",
            "An illustrative match often associated with upper-respiratory symptoms.",
            weights("runny nose","3","sneezing","3","cough","2","sore throat","2","fatigue","1"),
            tests("fever","Temperature check (basic assessment)","cough","Clinical respiratory assessment")));
        KNOWLEDGE_BASE.add(new Condition("Influenza-like illness",
            "An illustrative match for a flu-like symptom pattern; several illnesses can look similar.",
            weights("fever","3","cough","2","body aches","3","fatigue","2","headache","2","sore throat","1"),
            tests("fever","Temperature check (basic assessment)","cough","Clinical respiratory assessment")));
        KNOWLEDGE_BASE.add(new Condition("Seasonal allergy pattern",
            "An illustrative match for sneezing, nasal symptoms and itchy or watery eyes.",
            weights("sneezing","3","runny nose","3","itchy eyes","3","rash","1"),
            tests("itchy eyes","Clinician allergy-history assessment","rash","Skin assessment by a clinician")));
        KNOWLEDGE_BASE.add(new Condition("Migraine-like headache",
            "An illustrative match for headache with nausea or light sensitivity.",
            weights("headache","3","nausea","2","vomiting","2","light sensitivity","3","dizziness","1"),
            tests("light sensitivity","Clinical headache assessment","vomiting","Hydration and symptom assessment")));
        KNOWLEDGE_BASE.add(new Condition("Gastrointestinal illness pattern",
            "An illustrative match for digestive symptoms; causes vary widely.",
            weights("nausea","2","vomiting","3","diarrhea","3","abdominal pain","2","fever","1","fatigue","1"),
            tests("diarrhea","Hydration assessment","fever","Temperature check (basic assessment)")));
        KNOWLEDGE_BASE.add(new Condition("Respiratory illness requiring assessment",
            "A broad illustrative category; breathing or chest symptoms can require prompt assessment.",
            weights("cough","2","fever","2","shortness of breath","3","chest pain","2","fatigue","1"),
            tests("shortness of breath","Prompt clinical respiratory assessment","chest pain","Prompt clinical chest-pain assessment")));
    }

    private static void handleMatch(HttpExchange exchange) throws IOException {
        addCors(exchange);
        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }
        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendJson(exchange, 405, "{\"error\":\"Use POST for symptom matching.\"}");
            return;
        }

        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        String input = extractJsonString(body, "symptoms");
        if (input == null || input.trim().isEmpty()) {
            sendJson(exchange, 400, "{\"error\":\"Please enter at least one symptom.\"}");
            return;
        }
        if (input.length() > 1200) {
            sendJson(exchange, 400, "{\"error\":\"Please keep the symptom description under 1200 characters.\"}");
            return;
        }

        Set<String> normalized = normalizeSymptoms(input);
        if (normalized.isEmpty()) {
            sendJson(exchange, 200, "{\"recognized\":[],\"results\":[],\"tests\":[],\"message\":\"No supported symptoms were recognized. Try simple terms such as fever, cough, headache, nausea, or runny nose.\"}");
            return;
        }

        List<Map<String, Object>> results = new ArrayList<>();
        for (Condition condition : KNOWLEDGE_BASE) {
            int earned = 0;
            int possible = 0;
            List<String> matched = new ArrayList<>();
            for (Map.Entry<String, Integer> entry : condition.symptomWeights.entrySet()) {
                possible += entry.getValue();
                if (normalized.contains(entry.getKey())) {
                    earned += entry.getValue();
                    matched.add(entry.getKey());
                }
            }
            if (earned > 0) {
                int score = (int) Math.round(100.0 * earned / Math.max(1, possible));
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("name", condition.name);
                item.put("description", condition.description);
                item.put("score", score);
                item.put("matched", matched);
                item.put("matchedWeight", earned);
                results.add(item);
            }
        }
        results.sort((a, b) -> Integer.compare((int)b.get("score"), (int)a.get("score")));
        if (results.size() > 5) results = new ArrayList<>(results.subList(0, 5));

        List<String> recommendedTests = chooseDiscriminatingTests(normalized, results);
        String json = toResponseJson(normalized, results, recommendedTests);
        sendJson(exchange, 200, json);
    }

    // Simple normalization: lowercase, remove punctuation, then map phrases/synonyms.
    private static Set<String> normalizeSymptoms(String input) {
        String cleaned = input.toLowerCase(Locale.ROOT)
            .replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
        Set<String> found = new LinkedHashSet<>();
        // Phrase matching first preserves multi-word aliases.
        List<String> aliases = new ArrayList<>(NORMALIZATION.keySet());
        aliases.sort((a, b) -> Integer.compare(b.length(), a.length()));
        for (String alias : aliases) {
            if ((" " + cleaned + " ").contains(" " + alias + " ")) {
                found.add(NORMALIZATION.get(alias));
            }
        }
        // Direct canonical-word fallback.
        for (String word : cleaned.split(" ")) {
            if (NORMALIZATION.containsKey(word)) found.add(NORMALIZATION.get(word));
        }
        return found;
    }

    // Greedy test selection: select tests that cover the most currently distinguishing symptoms.
    private static List<String> chooseDiscriminatingTests(Set<String> input, List<Map<String, Object>> results) {
        LinkedHashSet<String> candidates = new LinkedHashSet<>();
        for (Condition c : KNOWLEDGE_BASE) {
            for (String symptom : input) {
                if (c.testBySymptom.containsKey(symptom)) candidates.add(c.testBySymptom.get(symptom));
            }
        }
        List<String> chosen = new ArrayList<>();
        for (String candidate : candidates) {
            if (chosen.size() == 3) break;
            if (!chosen.contains(candidate)) chosen.add(candidate);
        }
        return chosen;
    }

    private static String toResponseJson(Set<String> recognized, List<Map<String, Object>> results,
                                         List<String> tests) {
        StringBuilder out = new StringBuilder("{\"recognized\":[");
        int i = 0;
        for (String s : recognized) { if (i++ > 0) out.append(','); out.append(q(s)); }
        out.append("],\"results\":[");
        for (i = 0; i < results.size(); i++) {
            if (i > 0) out.append(',');
            Map<String, Object> r = results.get(i);
            out.append("{\"name\":").append(q((String)r.get("name")))
                .append(",\"description\":").append(q((String)r.get("description")))
                .append(",\"score\":").append(r.get("score")).append(",\"matched\":[");
            List<String> matched = (List<String>) r.get("matched");
            for (int j = 0; j < matched.size(); j++) { if (j > 0) out.append(','); out.append(q(matched.get(j))); }
            out.append("]}");
        }
        out.append("],\"tests\":[");
        for (i = 0; i < tests.size(); i++) { if (i > 0) out.append(','); out.append(q(tests.get(i))); }
        out.append("],\"message\":").append(q("Matching scores show overlap with this demonstration knowledge base. They are not medical probabilities or a diagnosis.")).append('}');
        return out.toString();
    }

    private static String extractJsonString(String json, String key) {
        // Small dependency-free parser for this one expected JSON string field.
        String marker = "\"" + key + "\"";
        int keyAt = json.indexOf(marker);
        if (keyAt < 0) return null;
        int colon = json.indexOf(':', keyAt + marker.length());
        if (colon < 0) return null;
        int start = json.indexOf('"', colon + 1);
        if (start < 0) return null;
        StringBuilder value = new StringBuilder();
        boolean escape = false;
        for (int i = start + 1; i < json.length(); i++) {
            char c = json.charAt(i);
            if (escape) {
                switch (c) {
                    case 'n': value.append('\n'); break;
                    case 'r': value.append('\r'); break;
                    case 't': value.append('\t'); break;
                    default: value.append(c);
                }
                escape = false;
            } else if (c == '\\') escape = true;
            else if (c == '"') return value.toString();
            else value.append(c);
        }
        return null;
    }

    private static String q(String value) {
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"")
            .replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t") + "\"";
    }

    private static void handleStatic(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath();
        if ("/".equals(path)) path = "/index.html";
        Path file = PUBLIC_DIR.resolve(path.substring(1)).normalize();
        if (!file.startsWith(PUBLIC_DIR.normalize()) || !Files.exists(file) || Files.isDirectory(file)) {
            byte[] notFound = "Not found".getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(404, notFound.length);
            try (OutputStream os = exchange.getResponseBody()) { os.write(notFound); }
            return;
        }
        String type = file.toString().endsWith(".css") ? "text/css; charset=utf-8"
            : file.toString().endsWith(".js") ? "application/javascript; charset=utf-8"
            : "text/html; charset=utf-8";
        byte[] bytes = Files.readAllBytes(file);
        exchange.getResponseHeaders().set("Content-Type", type);
        exchange.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) { os.write(bytes); }
    }

    private static void addCors(HttpExchange exchange) {
        Headers h = exchange.getResponseHeaders();
        h.set("Access-Control-Allow-Origin", "*");
        h.set("Access-Control-Allow-Headers", "Content-Type");
        h.set("Access-Control-Allow-Methods", "POST, OPTIONS");
    }

    private static void sendJson(HttpExchange exchange, int status, String json) throws IOException {
        addCors(exchange);
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) { os.write(bytes); }
    }
}
